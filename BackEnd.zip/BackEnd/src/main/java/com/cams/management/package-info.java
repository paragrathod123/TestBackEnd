/**
 * Application management.
 */
package com.cams.management;
