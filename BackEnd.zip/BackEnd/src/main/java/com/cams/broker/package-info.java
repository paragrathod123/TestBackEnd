/**
 * Spring cloud consumers and providers
 */
package com.cams.broker;
