/**
 * Rest layer error handling.
 */
package com.cams.web.rest.errors;
