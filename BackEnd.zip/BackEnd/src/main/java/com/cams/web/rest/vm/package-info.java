/**
 * Rest layer visual models.
 */
package com.cams.web.rest.vm;
