/**
 * Rest layer.
 */
package com.cams.web.rest;
