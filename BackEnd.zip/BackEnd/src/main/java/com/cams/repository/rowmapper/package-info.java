/**
 * Webflux database column mapper.
 */
package com.cams.repository.rowmapper;
