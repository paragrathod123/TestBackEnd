/**
 * Domain objects.
 */
package com.cams.domain;
