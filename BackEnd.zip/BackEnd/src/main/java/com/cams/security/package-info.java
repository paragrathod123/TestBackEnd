/**
 * Application security utilities.
 */
package com.cams.security;
