/**
 * Service layer.
 */
package com.cams.service;
