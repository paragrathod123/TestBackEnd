/**
 * Logging aspect.
 */
package com.cams.aop.logging;
