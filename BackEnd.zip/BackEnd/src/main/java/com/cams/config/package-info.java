/**
 * Application configuration.
 */
package com.cams.config;
